import { useState, useEffect } from "react";

const CATEGORIES = ["Nutrition","Mental Health","Fitness","Mindfulness","Sleep","Stress Management","Holistic Health","Lifestyle"];

const COLORS = {
  ink: "#1a1409",
  parchment: "#f5f0e8",
  cream: "#faf7f2",
  gold: "#c49a3c",
  goldLight: "#e8c97a",
  rust: "#8b3a2a",
  sage: "#4a6741",
  muted: "#7a7060",
  border: "#ddd5c0",
};

const ADMIN_PASSWORD = "wellnessatitsfinest";

const WELLNESS_ROUTINE_POST = {
  id: 1745000000001,
  title: "Feel Your Best, Even When Life Gets Busy: A Wellness Routine for Real People",
  category: "Lifestyle",
  date: "April 19, 2025",
  body: `Most wellness advice was written for people with unlimited time, a personal chef, and a gym in their building. This isn't that.

This routine is built around the reality that you have meetings, kids, deadlines, and a commute. It works in 15-minute windows, stacks habits you already have, and gives you real results without overhauling your life.

────────────────────────
PART 1: THE 15-MINUTE MORNING RITUAL
────────────────────────

The first 15 minutes set the tone for your entire day. These steps work even on the most chaotic mornings.

1. Hydrate before your phone (2 min)
Drink a full glass of water before checking any notifications. Overnight dehydration quietly tanks your focus and mood — this one act replenishes it.

2. Three deep breaths + set one intention (3 min)
Slow exhales activate your parasympathetic system. Then ask yourself: "What's the one thing that would make today feel successful?" Write it down or say it aloud.

3. Light movement — whatever feels good (10 min)
A 10-minute walk, yoga stretches, or a quick bodyweight circuit. The goal isn't intensity — it's signaling to your body that today is a go day. Bonus: do it outside for natural light exposure.

🔑 Busy-person hack: Stack the movement with something you're already doing. Do calf raises while making coffee. Do a 5-min stretch while your laptop boots up. Habit stacking is your superpower.

────────────────────────
PART 2: THE MIDDAY RESET
────────────────────────

Around 1–2 PM, most people hit a wall. Instead of reaching for caffeine, try this energy reset that actually lasts.

1. Step away from your screen (2 min)
Even a 5-minute break from digital stimulation reduces cortisol and mental fatigue. Walk to the water cooler, step outside, or simply look out a window at something distant.

2. Eat something real — without multitasking (2 min)
Eating while working keeps your nervous system in "alert" mode and impairs digestion. Give yourself permission to just eat. Even 10 minutes of mindful eating is deeply restorative.

3. Body check-in (1 min)
Where are you holding tension? Shoulders up? Jaw clenched? Spend 60 seconds consciously relaxing those areas. You'll often find you've been carrying stress without realizing it.

🔑 Can't leave your desk? Set a phone alarm labeled "Look up. Breathe. Unclench." at 1:30 PM daily. That reminder alone — if you actually follow it — is worth more than most wellness apps.

────────────────────────
PART 3: THE 10-MINUTE WIND-DOWN
────────────────────────

How you end your day determines how well you sleep — and how tomorrow begins. This routine signals safety to your nervous system.

1. Screens off 30 minutes before bed
Blue light suppresses melatonin production for up to 3 hours. If that sounds impossible, use night mode and lower brightness after 9 PM as a minimum. Your sleep quality will visibly improve within a week.

2. Three gratitudes + tomorrow's one priority (5 min)
Write three specific things you're grateful for (not generic — the more specific, the more effective). Then write down the single most important task for tomorrow so your brain can release it and actually rest.

3. Progressive relaxation or stretching (5 min)
A simple legs-up-the-wall pose for 5 minutes drains tension from your lower body and calms the nervous system. Or try a basic progressive muscle relaxation: tense and release each muscle group from feet to face.

🔑 The rule of one: If you only do ONE thing from this evening routine, make it the gratitude + priority note. It takes 3 minutes and the compounding effect on mood and sleep is remarkable.

────────────────────────
PART 4: YOUR WEEKLY ANCHOR HABIT
────────────────────────

Pick one. Do it every week without negotiating. Consistency over intensity — one protected hour each week builds the foundation everything else rests on.

A. Movement you actually enjoy
A hike, dance class, swim, or anything that doesn't feel like a chore. Enjoyment is the only form of exercise that's sustainable long-term. Put it in your calendar like a meeting you can't cancel.

B. A real social connection
Face-to-face time with someone who energizes you. Chronic loneliness is a greater health risk than obesity or smoking. Even a 45-minute coffee with a friend resets your social baseline.

C. A tech-free hour
One hour with no phone, no laptop, no TV. Read a physical book, cook a real meal, draw, journal, sit in a park. Let your brain experience boredom — it's where creativity and recovery actually happen.

────────────────────────
PART 5: THE MINDSET THAT MAKES IT STICK
────────────────────────

Most routines fail not because of lack of discipline, but because of how we talk to ourselves when we miss a day.

✓ Never miss twice
Missing one day is a pause. Missing two days is the start of a new habit (not doing the thing). The goal isn't perfection — it's preventing the gap from growing.

✓ Progress beats perfection every time
A 5-minute walk on a hard day is infinitely better than no walk because you couldn't do 30 minutes. Scaled-down versions of your habits still count. Always.

✓ Energy is an output, not an input
You don't wait until you have energy to do these habits — you do the habits and the energy follows. Movement, hydration, rest, and connection create the energy. They're not a reward for already having it.

────────────────────────
YOUR DAILY BLUEPRINT AT A GLANCE
────────────────────────

Morning  →  Hydrate + Intend + Move  (15 min)
Midday   →  Step away + Eat + Check in  (5 min)
Evening  →  Screens off + Gratitude + Stretch  (10 min)
Weekly   →  One anchor habit you protect  (60 min)

Start with just one thing. Pick the single habit that resonates most and do it consistently for two weeks. Then add one more. Wellness isn't a destination — it's a collection of small, repeated choices that compound over time into a life that genuinely feels good.`,
};

const styles = {
  body: { fontFamily: "'Georgia', serif", background: COLORS.cream, color: COLORS.ink, minHeight: "100vh", margin: 0 },
  header: { background: COLORS.ink, padding: "0 2rem", borderBottom: `2px solid ${COLORS.gold}`, position: "sticky", top: 0, zIndex: 100 },
  headerInner: { maxWidth: 1100, margin: "0 auto", display: "flex", alignItems: "center", justifyContent: "space-between", height: 64 },
  logo: { fontFamily: "'Georgia', serif", fontSize: "1.5rem", color: COLORS.parchment, letterSpacing: "0.04em", fontWeight: "normal" },
  logoAccent: { color: COLORS.gold },
  nav: { display: "flex", gap: "1.5rem", alignItems: "center" },
  navLink: { color: COLORS.border, textDecoration: "none", fontSize: "0.8rem", fontFamily: "sans-serif", fontWeight: 500, letterSpacing: "0.08em", textTransform: "uppercase", cursor: "pointer", background: "none", border: "none", padding: 0 },
  btnNew: { background: COLORS.gold, color: COLORS.ink, border: "none", padding: "0.5rem 1.2rem", fontFamily: "sans-serif", fontSize: "0.8rem", fontWeight: 600, letterSpacing: "0.08em", textTransform: "uppercase", cursor: "pointer", borderRadius: 2 },
  hero: { background: COLORS.parchment, borderBottom: `1px solid ${COLORS.border}`, padding: "3rem 2rem", textAlign: "center" },
  heroEyebrow: { fontSize: "0.72rem", letterSpacing: "0.2em", textTransform: "uppercase", color: COLORS.gold, fontFamily: "sans-serif", fontWeight: 500, marginBottom: "0.75rem" },
  heroH1: { fontFamily: "'Georgia', serif", fontSize: "clamp(1.8rem, 4vw, 3rem)", fontWeight: "normal", lineHeight: 1.15, marginBottom: "0.75rem", color: COLORS.ink },
  heroEm: { fontStyle: "italic", color: COLORS.rust },
  heroP: { color: COLORS.muted, fontSize: "0.95rem", maxWidth: 460, margin: "0 auto", lineHeight: 1.6, fontFamily: "sans-serif" },
  ticker: { background: COLORS.gold, overflow: "hidden", padding: "0.35rem 0", whiteSpace: "nowrap" },
  main: { maxWidth: 1100, margin: "0 auto", padding: "2.5rem 2rem", display: "grid", gridTemplateColumns: "1fr 280px", gap: "3rem", alignItems: "start" },
  postsHeader: { display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: "1.5rem", paddingBottom: "0.75rem", borderBottom: `2px solid ${COLORS.ink}` },
  postsTitle: { fontFamily: "'Georgia', serif", fontSize: "1.1rem", fontWeight: "bold", letterSpacing: "0.04em" },
  postsCount: { fontSize: "0.78rem", color: COLORS.muted, fontFamily: "sans-serif" },
  featuredPost: { background: COLORS.ink, color: COLORS.parchment, padding: "2rem", marginBottom: "1.5rem", cursor: "pointer", position: "relative", overflow: "hidden", transition: "transform 0.2s", borderRadius: 2 },
  featuredBadge: { display: "inline-block", background: COLORS.gold, color: COLORS.ink, fontSize: "0.62rem", fontWeight: 600, letterSpacing: "0.15em", textTransform: "uppercase", padding: "0.2rem 0.55rem", marginBottom: "1rem", fontFamily: "sans-serif" },
  featuredTitle: { fontFamily: "'Georgia', serif", fontSize: "1.6rem", fontWeight: "normal", lineHeight: 1.2, marginBottom: "0.75rem" },
  featuredExcerpt: { color: COLORS.border, fontSize: "0.88rem", lineHeight: 1.65, marginBottom: "1.2rem", fontFamily: "sans-serif" },
  postMeta: { display: "flex", gap: "1rem", fontSize: "0.72rem", color: "#9a8f78", letterSpacing: "0.06em", alignItems: "center", fontFamily: "sans-serif" },
  postCard: { borderBottom: `1px solid ${COLORS.border}`, padding: "1.5rem 0", display: "grid", gridTemplateColumns: "1fr auto", gap: "1.2rem", alignItems: "start", cursor: "pointer" },
  postTag: { display: "inline-block", fontSize: "0.62rem", fontWeight: 600, letterSpacing: "0.15em", textTransform: "uppercase", color: COLORS.sage, marginBottom: "0.4rem", fontFamily: "sans-serif" },
  postTitle: { fontFamily: "'Georgia', serif", fontSize: "1.15rem", fontWeight: "normal", lineHeight: 1.3, marginBottom: "0.4rem", color: COLORS.ink },
  postExcerpt: { fontSize: "0.85rem", color: COLORS.muted, lineHeight: 1.6, fontFamily: "sans-serif" },
  postNumber: { fontFamily: "'Georgia', serif", fontSize: "2.2rem", color: COLORS.border, lineHeight: 1 },
  editBtn: { background: "none", border: `1px solid ${COLORS.border}`, color: COLORS.muted, fontSize: "0.68rem", fontFamily: "sans-serif", padding: "0.2rem 0.5rem", cursor: "pointer", borderRadius: 2 },
  deleteBtn: { background: "none", border: `1px solid ${COLORS.border}`, color: COLORS.muted, fontSize: "0.68rem", fontFamily: "sans-serif", padding: "0.2rem 0.5rem", cursor: "pointer", borderRadius: 2 },
  featuredActionRow: { display: "flex", gap: "0.5rem", marginBottom: "0.75rem" },
  featuredEditBtn: { background: "rgba(255,255,255,0.08)", border: "1px solid rgba(255,255,255,0.2)", color: "#c9bfa8", fontSize: "0.68rem", fontFamily: "sans-serif", padding: "0.25rem 0.6rem", cursor: "pointer", borderRadius: 2 },
  sidebar: { position: "sticky", top: 80 },
  widget: { border: `1px solid ${COLORS.border}`, padding: "1.25rem", marginBottom: "1.25rem", background: COLORS.parchment, borderRadius: 2 },
  widgetTitle: { fontSize: "0.68rem", fontWeight: 600, letterSpacing: "0.18em", textTransform: "uppercase", color: COLORS.muted, fontFamily: "sans-serif", marginBottom: "1rem", paddingBottom: "0.6rem", borderBottom: `1px solid ${COLORS.border}` },
  widgetText: { fontSize: "0.85rem", color: COLORS.muted, lineHeight: 1.65, fontFamily: "sans-serif" },
  catItem: { display: "flex", justifyContent: "space-between", padding: "0.45rem 0", fontSize: "0.85rem", cursor: "pointer", fontFamily: "sans-serif", background: "none", border: "none", width: "100%", textAlign: "left", color: COLORS.ink },
  catCount: { fontSize: "0.75rem", color: COLORS.muted },
  subInput: { width: "100%", border: `1px solid ${COLORS.border}`, background: COLORS.cream, padding: "0.55rem 0.75rem", fontFamily: "sans-serif", fontSize: "0.85rem", color: COLORS.ink, marginBottom: "0.6rem", outline: "none", boxSizing: "border-box", borderRadius: 2 },
  subBtn: { width: "100%", background: COLORS.ink, color: COLORS.parchment, border: "none", padding: "0.6rem", fontFamily: "sans-serif", fontSize: "0.78rem", fontWeight: 600, letterSpacing: "0.1em", textTransform: "uppercase", cursor: "pointer", borderRadius: 2 },
  emptyState: { textAlign: "center", padding: "3rem 1rem", color: COLORS.muted, fontFamily: "sans-serif" },
  overlay: { position: "fixed", inset: 0, background: "rgba(26,20,9,0.75)", zIndex: 200, display: "flex", alignItems: "center", justifyContent: "center", padding: "1rem" },
  modal: { background: COLORS.cream, width: "100%", maxWidth: 640, maxHeight: "90vh", overflowY: "auto", padding: "2rem", position: "relative", borderRadius: 2, boxShadow: "0 20px 60px rgba(0,0,0,0.4)" },
  modalTitle: { fontFamily: "'Georgia', serif", fontSize: "1.3rem", fontWeight: "normal", marginBottom: "1.5rem", paddingBottom: "0.75rem", borderBottom: `2px solid ${COLORS.ink}` },
  modalClose: { position: "absolute", top: "1rem", right: "1.2rem", background: "none", border: "none", fontSize: "1.5rem", cursor: "pointer", color: COLORS.muted, lineHeight: 1 },
  label: { display: "block", fontSize: "0.7rem", fontWeight: 600, letterSpacing: "0.1em", textTransform: "uppercase", color: COLORS.muted, fontFamily: "sans-serif", marginBottom: "0.35rem" },
  input: { width: "100%", border: `1px solid ${COLORS.border}`, background: COLORS.parchment, padding: "0.65rem 0.8rem", fontFamily: "'Georgia', serif", fontSize: "0.92rem", color: COLORS.ink, outline: "none", boxSizing: "border-box", borderRadius: 2, marginBottom: "1rem" },
  select: { width: "100%", border: `1px solid ${COLORS.border}`, background: COLORS.parchment, padding: "0.65rem 0.8rem", fontFamily: "sans-serif", fontSize: "0.92rem", color: COLORS.ink, outline: "none", boxSizing: "border-box", borderRadius: 2, marginBottom: "1rem" },
  textarea: { width: "100%", border: `1px solid ${COLORS.border}`, background: COLORS.parchment, padding: "0.65rem 0.8rem", fontFamily: "'Georgia', serif", fontSize: "0.92rem", color: COLORS.ink, outline: "none", boxSizing: "border-box", borderRadius: 2, minHeight: 200, resize: "vertical", marginBottom: "1rem" },
  formActions: { display: "flex", gap: "0.75rem", marginTop: "0.5rem", paddingTop: "1rem", borderTop: `1px solid ${COLORS.border}` },
  btnPublish: { background: COLORS.ink, color: COLORS.parchment, border: "none", padding: "0.7rem 1.6rem", fontFamily: "sans-serif", fontSize: "0.82rem", fontWeight: 600, letterSpacing: "0.1em", textTransform: "uppercase", cursor: "pointer", borderRadius: 2 },
  btnCancel: { background: "none", color: COLORS.muted, border: `1px solid ${COLORS.border}`, padding: "0.7rem 1.2rem", fontFamily: "sans-serif", fontSize: "0.82rem", cursor: "pointer", borderRadius: 2 },
  readCatBadge: { display: "inline-block", background: COLORS.sage, color: "white", fontSize: "0.62rem", fontWeight: 600, letterSpacing: "0.15em", textTransform: "uppercase", padding: "0.2rem 0.55rem", marginBottom: "1rem", fontFamily: "sans-serif", borderRadius: 2 },
  readTitle: { fontFamily: "'Georgia', serif", fontSize: "1.8rem", fontWeight: "normal", lineHeight: 1.2, marginBottom: "0.5rem" },
  readMeta: { fontSize: "0.78rem", color: COLORS.muted, fontFamily: "sans-serif", marginBottom: "1.5rem", paddingBottom: "1.2rem", borderBottom: `2px solid ${COLORS.ink}` },
  readBody: { fontSize: "0.95rem", lineHeight: 1.85, color: "#2a2215", fontFamily: "'Georgia', serif", whiteSpace: "pre-wrap" },
  footer: { background: COLORS.ink, color: COLORS.border, textAlign: "center", padding: "1.2rem", fontSize: "0.75rem", letterSpacing: "0.06em", borderTop: `2px solid ${COLORS.gold}`, fontFamily: "sans-serif" },
  adminLoginBox: { position: "fixed", bottom: "1.5rem", right: "1.5rem", zIndex: 300, background: COLORS.ink, border: `1px solid ${COLORS.gold}`, borderRadius: 6, padding: "1rem 1.2rem", boxShadow: "0 8px 32px rgba(0,0,0,0.35)", minWidth: 220 },
  adminLoginTitle: { fontSize: "0.68rem", fontWeight: 600, letterSpacing: "0.15em", textTransform: "uppercase", color: COLORS.gold, fontFamily: "sans-serif", marginBottom: "0.6rem" },
  adminLoginInput: { width: "100%", background: "rgba(255,255,255,0.07)", border: "1px solid rgba(255,255,255,0.15)", color: COLORS.parchment, padding: "0.5rem 0.7rem", fontFamily: "sans-serif", fontSize: "0.85rem", borderRadius: 3, outline: "none", boxSizing: "border-box", marginBottom: "0.5rem" },
  adminLoginBtn: { width: "100%", background: COLORS.gold, color: COLORS.ink, border: "none", padding: "0.5rem", fontFamily: "sans-serif", fontSize: "0.75rem", fontWeight: 700, letterSpacing: "0.1em", textTransform: "uppercase", cursor: "pointer", borderRadius: 3 },
  adminLoginErr: { fontSize: "0.72rem", color: "#e09080", fontFamily: "sans-serif", marginTop: "0.4rem" },
  adminBadge: { position: "fixed", bottom: "1.5rem", right: "1.5rem", zIndex: 300, background: COLORS.ink, border: `1px solid ${COLORS.gold}`, borderRadius: 6, padding: "0.5rem 1rem", display: "flex", alignItems: "center", gap: "0.6rem", boxShadow: "0 4px 16px rgba(0,0,0,0.3)" },
  adminBadgeText: { fontSize: "0.72rem", color: COLORS.gold, fontFamily: "sans-serif", fontWeight: 600, letterSpacing: "0.08em" },
  adminLogoutBtn: { background: "none", border: "1px solid rgba(255,255,255,0.2)", color: "#9a8f78", fontSize: "0.68rem", fontFamily: "sans-serif", padding: "0.2rem 0.5rem", cursor: "pointer", borderRadius: 3 },
};

function TickerBar() {
  const msgs = ["Welcome to DeeWellness Blog","Nourish your mind, body & soul","Expert wellness guidance for your journey","Your health, your transformation"];
  const all = [...msgs, ...msgs];
  return (
    <div style={styles.ticker}>
      <style>{`@keyframes ticker{0%{transform:translateX(0)}100%{transform:translateX(-50%)}}`}</style>
      <div style={{ display: "flex", gap: "3rem", animation: "ticker 28s linear infinite", whiteSpace: "nowrap" }}>
        {all.map((m, i) => (
          <span key={i} style={{ fontSize: "0.7rem", fontWeight: 600, letterSpacing: "0.12em", textTransform: "uppercase", color: COLORS.ink, fontFamily: "sans-serif" }}>
            {m} &nbsp;·&nbsp;
          </span>
        ))}
      </div>
    </div>
  );
}

export default function DeeWellnessBlog() {
  const [posts, setPosts] = useState([]);
  const [filter, setFilter] = useState("all");
  const [modal, setModal] = useState(null);
  const [editingPost, setEditingPost] = useState(null);
  const [readPost, setReadPostData] = useState(null);
  const [form, setForm] = useState({ title: "", category: "Nutrition", body: "" });
  const [subEmail, setSubEmail] = useState("");
  const [subMsg, setSubMsg] = useState("");
  const [hovered, setHovered] = useState(null);
  const [isAdmin, setIsAdmin] = useState(false);
  const [showAdminLogin, setShowAdminLogin] = useState(false);
  const [adminInput, setAdminInput] = useState("");
  const [adminErr, setAdminErr] = useState(false);

  function handleAdminLogin() {
    if (adminInput === ADMIN_PASSWORD) {
      setIsAdmin(true);
      setShowAdminLogin(false);
      setAdminInput("");
      setAdminErr(false);
    } else {
      setAdminErr(true);
      setAdminInput("");
    }
  }

  useEffect(() => {
    async function loadPosts() {
      try {
        const r = await window.storage?.get("deewellness_posts");
        if (r) {
          const saved = JSON.parse(r.value);
          const hasRoutinePost = saved.some(p => p.id === WELLNESS_ROUTINE_POST.id);
          if (!hasRoutinePost) {
            const updated = [WELLNESS_ROUTINE_POST, ...saved];
            setPosts(updated);
            await window.storage?.set("deewellness_posts", JSON.stringify(updated));
          } else {
            setPosts(saved);
          }
        } else {
          const initial = [WELLNESS_ROUTINE_POST];
          setPosts(initial);
          await window.storage?.set("deewellness_posts", JSON.stringify(initial));
        }
      } catch {
        setPosts([WELLNESS_ROUTINE_POST]);
      }
    }
    loadPosts();
  }, []);

  async function save(updated) {
    setPosts(updated);
    try { await window.storage?.set("deewellness_posts", JSON.stringify(updated)); } catch {}
  }

  function openNew() { setForm({ title: "", category: "Nutrition", body: "" }); setEditingPost(null); setModal("new"); }
  function openEdit(post, e) { e?.stopPropagation(); setForm({ title: post.title, category: post.category, body: post.body }); setEditingPost(post); setModal("edit"); }
  function openRead(post) { setReadPostData(post); setModal("read"); }
  function closeModal() { setModal(null); setEditingPost(null); setReadPostData(null); }

  function publish() {
    if (!form.title.trim()) return alert("Please add a title.");
    if (!form.body.trim()) return alert("Please write some content.");
    if (modal === "edit" && editingPost) {
      save(posts.map(p => p.id === editingPost.id ? { ...p, ...form, edited: true } : p));
    } else {
      const post = { id: Date.now(), ...form, date: new Date().toLocaleDateString("en-US", { year: "numeric", month: "long", day: "numeric" }) };
      save([post, ...posts]);
    }
    closeModal();
  }

  function deletePost(post, e) {
    e?.stopPropagation();
    if (!window.confirm(`Delete "${post.title}"?`)) return;
    save(posts.filter(p => p.id !== post.id));
    if (modal === "read") closeModal();
  }

  const filtered = filter === "all" ? posts : posts.filter(p => p.category === filter);
  const catCounts = posts.reduce((acc, p) => { acc[p.category] = (acc[p.category] || 0) + 1; return acc; }, {});

  return (
    <div style={styles.body}>
      <header style={styles.header}>
        <div style={styles.headerInner}>
          <div style={styles.logo}>Dee<span style={styles.logoAccent}>Wellness</span></div>
          <nav style={styles.nav}>
            <button style={styles.navLink} onClick={() => setFilter("all")}>All Posts</button>
            <button style={styles.navLink} onClick={() => setFilter("all")}>Categories</button>
            {isAdmin && <button style={styles.btnNew} onClick={openNew}>+ New Post</button>}
          </nav>
        </div>
      </header>

      <TickerBar />

      <div style={styles.hero}>
        <p style={styles.heroEyebrow}>Wellness Advice for Clients</p>
        <h1 style={styles.heroH1}>Feel better, live <em style={styles.heroEm}>fuller,</em> thrive always.</h1>
        <p style={styles.heroP}>Expert wellness guidance, practical tips, and holistic advice — curated for your journey to a healthier life.</p>
      </div>

      <div style={styles.main}>
        <div>
          <div style={styles.postsHeader}>
            <h2 style={styles.postsTitle}>Latest Articles</h2>
            <span style={styles.postsCount}>{filtered.length} article{filtered.length !== 1 ? "s" : ""}</span>
          </div>

          {filtered.length === 0 ? (
            <div style={styles.emptyState}>
              <div style={{ fontSize: "2rem", marginBottom: "0.75rem" }}>✦</div>
              <p>No articles yet. Click <strong>+ New Post</strong> to publish your first wellness article.</p>
            </div>
          ) : filtered.map((post, i) => (
            i === 0 && filter === "all" ? (
              <div key={post.id}
                style={{ ...styles.featuredPost, transform: hovered === post.id ? "translateY(-2px)" : "none" }}
                onClick={() => openRead(post)}
                onMouseEnter={() => setHovered(post.id)}
                onMouseLeave={() => setHovered(null)}
              >
                <div style={{ position: "absolute", top: 0, right: 0, width: 180, height: 180, background: "radial-gradient(circle, rgba(196,154,60,0.12) 0%, transparent 70%)", pointerEvents: "none" }} />
                <span style={styles.featuredBadge}>Featured</span>
                {isAdmin && (
                <div style={styles.featuredActionRow} onClick={e => e.stopPropagation()}>
                  <button style={styles.featuredEditBtn} onClick={e => openEdit(post, e)}>✎ Edit</button>
                  <button style={{ ...styles.featuredEditBtn, color: "#e09080" }} onClick={e => deletePost(post, e)}>✕ Delete</button>
                </div>
                )}
                <h3 style={styles.featuredTitle}>{post.title}</h3>
                <p style={styles.featuredExcerpt}>{post.body.substring(0, 200)}{post.body.length > 200 ? "…" : ""}</p>
                <div style={styles.postMeta}>
                  <span>{post.category}</span>
                  <span style={{ width: 3, height: 3, background: "currentColor", borderRadius: "50%", display: "inline-block" }} />
                  <span>{post.date}</span>
                </div>
              </div>
            ) : (
              <div key={post.id}
                style={{ ...styles.postCard }}
                onClick={() => openRead(post)}
                onMouseEnter={() => setHovered(post.id)}
                onMouseLeave={() => setHovered(null)}
              >
                <div>
                  <span style={styles.postTag}>{post.category}</span>
                  <h3 style={{ ...styles.postTitle, color: hovered === post.id ? COLORS.rust : COLORS.ink }}>{post.title}</h3>
                  <p style={styles.postExcerpt}>{post.body.substring(0, 120)}{post.body.length > 120 ? "…" : ""}</p>
                  <div style={{ ...styles.postMeta, color: COLORS.muted, marginTop: "0.6rem" }}>
                    <span>{post.date}</span>
                    {isAdmin && (
                    <span style={{ marginLeft: "auto", display: "flex", gap: "0.4rem" }} onClick={e => e.stopPropagation()}>
                      <button style={styles.editBtn} onClick={e => openEdit(post, e)}>✎ Edit</button>
                      <button style={styles.deleteBtn} onClick={e => deletePost(post, e)}>✕</button>
                    </span>
                    )}
                  </div>
                </div>
                <div style={styles.postNumber}>{String(i + 1).padStart(2, "0")}</div>
              </div>
            )
          ))}
        </div>

        <aside style={styles.sidebar}>
          <div style={styles.widget}>
            <div style={styles.widgetTitle}>About This Blog</div>
            <p style={styles.widgetText}>DeeWellness is your go-to space for holistic health guidance, wellness tips, and expert advice to help clients thrive in mind, body, and spirit.</p>
          </div>
          <div style={styles.widget}>
            <div style={styles.widgetTitle}>Categories</div>
            <div>
              {[["all", "All Topics", posts.length], ...Object.entries(catCounts).sort()].map(([cat, label, count]) => (
                <button key={cat} style={{ ...styles.catItem, fontWeight: filter === cat ? 600 : 400, borderBottom: `1px solid ${COLORS.border}`, paddingTop: "0.45rem", paddingBottom: "0.45rem" }} onClick={() => setFilter(cat)}>
                  <span>{typeof label === "string" ? label : cat}</span>
                  <span style={styles.catCount}>{typeof count === "number" ? count : label}</span>
                </button>
              ))}
            </div>
          </div>
          <div style={styles.widget}>
            <div style={styles.widgetTitle}>Stay Updated</div>
            <input style={styles.subInput} type="email" placeholder="Client email address" value={subEmail} onChange={e => setSubEmail(e.target.value)} />
            <button style={styles.subBtn} onClick={() => {
              if (!subEmail.includes("@")) return alert("Enter a valid email.");
              setSubMsg(`✓ ${subEmail} subscribed!`);
              setSubEmail("");
              setTimeout(() => setSubMsg(""), 3000);
            }}>Subscribe</button>
            {subMsg && <p style={{ fontSize: "0.78rem", color: COLORS.sage, marginTop: "0.5rem", fontFamily: "sans-serif" }}>{subMsg}</p>}
          </div>
        </aside>
      </div>

      <footer style={styles.footer}>
        DeeWellness Blog &nbsp;·&nbsp; Nourishing lives with <span style={{ color: COLORS.gold }}>♥</span>
      </footer>

      {(modal === "new" || modal === "edit") && (
        <div style={styles.overlay} onClick={closeModal}>
          <div style={styles.modal} onClick={e => e.stopPropagation()}>
            <button style={styles.modalClose} onClick={closeModal}>×</button>
            <h2 style={styles.modalTitle}>{modal === "edit" ? "Edit Article" : "Publish New Article"}</h2>
            <label style={styles.label}>Article Title</label>
            <input style={styles.input} value={form.title} onChange={e => setForm({ ...form, title: e.target.value })} placeholder="e.g. 5 Ways to Reduce Daily Stress" autoFocus />
            <label style={styles.label}>Category</label>
            <select style={styles.select} value={form.category} onChange={e => setForm({ ...form, category: e.target.value })}>
              {CATEGORIES.map(c => <option key={c}>{c}</option>)}
            </select>
            <label style={styles.label}>Article Content</label>
            <textarea style={styles.textarea} value={form.body} onChange={e => setForm({ ...form, body: e.target.value })} placeholder="Share your wellness advice here..." />
            <div style={styles.formActions}>
              <button style={styles.btnPublish} onClick={publish}>{modal === "edit" ? "Save Changes" : "Publish Article"}</button>
              <button style={styles.btnCancel} onClick={closeModal}>Cancel</button>
            </div>
          </div>
        </div>
      )}

      {modal === "read" && readPost && (
        <div style={styles.overlay} onClick={closeModal}>
          <div style={styles.modal} onClick={e => e.stopPropagation()}>
            <button style={styles.modalClose} onClick={closeModal}>×</button>
            <span style={styles.readCatBadge}>{readPost.category}</span>
            <h2 style={styles.readTitle}>{readPost.title}</h2>
            <div style={styles.readMeta}>{readPost.date}{readPost.edited ? " · Edited" : ""}</div>
            <div style={styles.readBody}>{readPost.body}</div>
            {isAdmin && (
            <div style={{ ...styles.formActions, marginTop: "2rem" }}>
              <button style={styles.btnPublish} onClick={e => { closeModal(); setTimeout(() => openEdit(readPost, e), 50); }}>✎ Edit Article</button>
              <button style={styles.btnCancel} onClick={e => deletePost(readPost, e)}>✕ Delete</button>
            </div>
            )}
          </div>
        </div>
      )}

      {/* ADMIN FLOATING UI */}
      {!isAdmin && !showAdminLogin && (
        <button onClick={() => setShowAdminLogin(true)} style={{ position: "fixed", bottom: "1.5rem", right: "1.5rem", zIndex: 300, background: "rgba(26,20,9,0.7)", border: "1px solid rgba(196,154,60,0.3)", color: "rgba(196,154,60,0.5)", fontSize: "0.65rem", fontFamily: "sans-serif", letterSpacing: "0.12em", textTransform: "uppercase", padding: "0.4rem 0.8rem", borderRadius: 4, cursor: "pointer" }}>
          Admin
        </button>
      )}

      {!isAdmin && showAdminLogin && (
        <div style={styles.adminLoginBox}>
          <div style={styles.adminLoginTitle}>🔒 Admin Login</div>
          <input
            style={styles.adminLoginInput}
            type="password"
            placeholder="Enter password"
            value={adminInput}
            onChange={e => { setAdminInput(e.target.value); setAdminErr(false); }}
            onKeyDown={e => e.key === "Enter" && handleAdminLogin()}
            autoFocus
          />
          {adminErr && <div style={styles.adminLoginErr}>Incorrect password. Try again.</div>}
          <button style={styles.adminLoginBtn} onClick={handleAdminLogin}>Unlock</button>
          <button onClick={() => { setShowAdminLogin(false); setAdminInput(""); setAdminErr(false); }} style={{ ...styles.adminLoginBtn, background: "none", color: "#9a8f78", border: "1px solid rgba(255,255,255,0.1)", marginTop: "0.4rem" }}>Cancel</button>
        </div>
      )}

      {isAdmin && (
        <div style={styles.adminBadge}>
          <span style={styles.adminBadgeText}>✦ Admin Mode</span>
          <button style={styles.adminLogoutBtn} onClick={() => setIsAdmin(false)}>Log out</button>
        </div>
      )}
    </div>
  );
}
